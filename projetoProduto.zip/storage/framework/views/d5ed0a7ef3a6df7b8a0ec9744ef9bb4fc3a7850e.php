<html>
    <head>
    </head>

    <body>
        <h1>
            Teste
        </h1>
    </body>
</html>
<?php /**PATH /application/resources/views/teste.blade.php ENDPATH**/ ?>