<?php $__env->startSection("content"); ?>
    <div class="col-md-12">
        <h3>Editar contato</h3>
    </div>

    <div class="col-md-6 well">
        <form col-md-12 action="<?php echo e(url('/produtos/put')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="ID_PRODUTO_PRD" value="<?php echo e($produto->ID_PRODUTO_PRD); ?>">
            <div class="form-group col-md-12">
                <label class="control-label"></label>
                    <input type = "text" name="ST_DESCRICAO_PRD" value = "<?php echo e($produto->ST_DESCRICAO_PRD); ?>" class="form-control" placeholder="Nome">
            </div>

            <div class="col-md-12">
                <button style = "float:right"class="btn btn-primary">Salvar</button>
            </div>

        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /application/resources/views/produtos/edit.blade.php ENDPATH**/ ?>