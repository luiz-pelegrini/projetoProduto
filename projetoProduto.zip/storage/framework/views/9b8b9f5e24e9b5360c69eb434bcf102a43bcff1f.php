<?php $__env->startSection("content"); ?>

    <style>
        .btn-action {
            padding: 5px;
            float: right;
        }
    </style>

    <div>
        <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">

            <div class="panel panel-info">
                <div class="panel-heading">

                    <?php echo e($produto->ST_DESCRICAO_PRD); ?>

                    <a href="<?php echo e(url("/produtos/$produto->ID_PRODUTO_PRD/editar")); ?>" class="btn btn-xs btn-primary btn-action" >
                    <i class="glyphicon glyphicon-pencil">
                    </i>
                    </a>

                    <a href="<?php echo e(url("/produtos/$produto->ID_PRODUTO_PRD/delete")); ?>" class="btn btn-xs btn-danger btn-action" >
                    <i class="glyphicon glyphicon-trash">
                    </i>
                    </a>
                </div>
                <div class="panel-body">
                    <?php echo e($produto->ID_CONTACATEGORIA_CC); ?>

                </div>
            </div>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /application/resources/views/produtos/index.blade.php ENDPATH**/ ?>