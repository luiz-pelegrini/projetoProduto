<?php $__env->startSection("content"); ?>

    <style>
        .btn-action {
            padding: 5px;
            float: right;
        }
    </style>

    <div>
        <?php $__currentLoopData = $contacategoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">

            <div class="panel panel-info">
                <div class="panel-heading">
                    <?php echo e($cat->ST_DESCRICAO_CC); ?>

                    <a href="<?php echo e(url("/contacategoria/$cat->ID_CONTACATEGORIA_CC/editar")); ?>" class="btn btn-xs btn-primary btn-action btn-action" >
                    <i class="glyphicon glyphicon-pencil">
                    </i>
                    </a>

                    <a href="<?php echo e(url("/contacategoria/$cat->ID_CONTACATEGORIA_CC/delete")); ?>" class="btn btn-xs btn-danger btn-action btn-action" >
                    <i class="glyphicon glyphicon-trash">
                    </i>
                    </a>

                </div>
                <div class="panel-body">
                    <?php echo e($cat->ID_CONTACATEGORIA_CC); ?>

                </div>
            </div>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /application/resources/views/contacategoria/index.blade.php ENDPATH**/ ?>