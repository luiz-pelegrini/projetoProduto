<?php $__env->startSection("content"); ?>
    <div class="col-md-12">
        <h3>Novo conta categoria</h3>
    </div>

    <div class="col-md-6 well">
        <form col-md-12 action="<?php echo e(url('/contacategoria/post')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>


            <div class="form-group col-md-12">
                <label class="control-label"></label>
                    <input type = "text" name="ST_DESCRICAO_CC" class="form-control" placeholder="Nome conta categoria">
            </div>

            <div class="col-md-12">
                <button style = "float:right"class="btn btn-primary">Salvar</button>
            </div>

        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /application/resources/views/contacategoria/create.blade.php ENDPATH**/ ?>